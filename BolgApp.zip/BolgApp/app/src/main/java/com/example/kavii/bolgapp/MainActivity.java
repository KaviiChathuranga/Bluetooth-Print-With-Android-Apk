package com.example.kavii.bolgapp;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Set;
import java.util.UUID;
//import android.R.id.*;
//import android.app.Activity;

public class MainActivity extends Activity implements Runnable {
    private WebView myWebView;
    private EditText field;
    private ListView listView;

    protected static final String TAG = "TAG";
    private static final int REQUEST_CONNECT_DEVICE = 1;
    private static final int REQUEST_ENABLE_BT = 2;
    BluetoothAdapter mBluetoothAdapter;
    private UUID applicationUUID = UUID
            .fromString("00001101-0000-1000-8000-00805F9B34FB");
    private ProgressDialog mBluetoothConnectProgressDialog;
    private BluetoothSocket mBluetoothSocket;
    BluetoothDevice mBluetoothDevice;

    @SuppressLint("JavascriptInterface")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        myWebView = (WebView)findViewById(R.id.webView);
        listView = (ListView) findViewById(R.id.paired_devices);
        WebSettings webSettings = myWebView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        myWebView.getSettings().setJavaScriptEnabled(true);
        myWebView.getSettings().setDomStorageEnabled(true);
        myWebView.addJavascriptInterface(new WebAppInterface(this), "Android");
        myWebView.loadUrl("https://github.com/KaviiChathuranga");
        myWebView.setWebViewClient(new WebViewClient());
//        System.out.println("111");
//        listView =  findViewById(R.id.paired_devices);
//        System.out.println("2222");
//        listView.setOnClickListener(new View.OnClickListener() {
//
//            @Override
//            public void onClick(View v) {
//                System.out.println("List on Click ........................");
                //                    Thread t = new Thread() {
//                        public void run() {
//                            try {
//                                OutputStream os = mBluetoothSocket
//                                        .getOutputStream();
//                                String BILL = "";
//
//                                BILL = "                   XXXX MART    \n"
//                                        + "                   XX.AA.BB.CC.     \n " +
//                                        "                 NO 25 ABC ABCDE    \n" +
//                                        "                  XXXXX YYYYYY      \n" +
//                                        "                   MMM 590019091      \n";
//                                BILL = BILL
//                                        + "-----------------------------------------------\n";
//
//
//                                BILL = BILL + String.format("%1$-10s %2$10s %3$13s %4$10s", "Item", "Qty", "Rate", "Totel");
//                                BILL = BILL + "\n";
//                                BILL = BILL
//                                        + "-----------------------------------------------";
//                                BILL = BILL + "\n " + String.format("%1$-10s %2$10s %3$11s %4$10s", "item-001", "5", "10", "50.00");
//                                BILL = BILL + "\n " + String.format("%1$-10s %2$10s %3$11s %4$10s", "item-002", "10", "5", "50.00");
//                                BILL = BILL + "\n " + String.format("%1$-10s %2$10s %3$11s %4$10s", "item-003", "20", "10", "200.00");
//                                BILL = BILL + "\n " + String.format("%1$-10s %2$10s %3$11s %4$10s", "item-004", "50", "10", "500.00");
//
//                                BILL = BILL
//                                        + "\n-----------------------------------------------";
//                                BILL = BILL + "\n\n ";
//
//                                BILL = BILL + "                   Total Qty:" + "      " + "85" + "\n";
//                                BILL = BILL + "                   Total Value:" + "     " + "700.00" + "\n";
//
//                                BILL = BILL
//                                        + "-----------------------------------------------\n";
//                                BILL = BILL + "\n\n ";
//                                os.write(BILL.getBytes());
//                                //This is printer specific code you can comment ==== > Start
//
//                                // Setting height
//                                int gs = 29;
//                                os.write(intToByteArray(gs));
//                                int h = 104;
//                                os.write(intToByteArray(h));
//                                int n = 162;
//                                os.write(intToByteArray(n));
//
//                                // Setting Width
//                                int gs_width = 29;
//                                os.write(intToByteArray(gs_width));
//                                int w = 119;
//                                os.write(intToByteArray(w));
//                                int n_width = 2;
//                                os.write(intToByteArray(n_width));
//
//
//                            } catch (Exception e) {
//                                Log.e("MainActivity", "Exe ", e);
//                            }
//                        }
//                    };
//                    t.start();
//            }
//        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
//        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }
    @Override
    protected void onDestroy() {
        // TODO Auto-generated method stub
        super.onDestroy();
        try {
            if (mBluetoothSocket != null)
                mBluetoothSocket.close();
        } catch (Exception e) {
            Log.e("Tag", "Exe ", e);
        }
    }

    @Override
    public void onBackPressed() {
        try {
            if (mBluetoothSocket != null)
                mBluetoothSocket.close();
        } catch (Exception e) {
            Log.e("Tag", "Exe ", e);
        }
        setResult(RESULT_CANCELED);
        finish();
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
            if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public void run() {
        try {
            mBluetoothSocket = mBluetoothDevice
                    .createRfcommSocketToServiceRecord(applicationUUID);
            System.out.println("soket ok............");
            mBluetoothAdapter.cancelDiscovery();
            mBluetoothSocket.connect();
            mHandler.sendEmptyMessage(0);
        } catch (IOException eConnectException) {
            Log.d(TAG, "CouldNotConnectToSocket", eConnectException);
            closeSocket(mBluetoothSocket);
            return;
        }
    }

    private void closeSocket(BluetoothSocket nOpenSocket) {
        try {
            nOpenSocket.close();
            Log.d(TAG, "SocketClosed");
        } catch (IOException ex) {
            Log.d(TAG, "CouldNotCloseSocket");
        }
    }

    private Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
           final String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(Calendar.getInstance().getTime());

            mBluetoothConnectProgressDialog.dismiss();
            Toast.makeText(MainActivity.this, "DeviceConnected", Toast.LENGTH_SHORT).show();

            Thread t = new Thread() {
                        public void run() {
                            try {
                                OutputStream os = mBluetoothSocket
                                        .getOutputStream();
                                String BILL = "";

                                BILL = "                   XXXX MART    \n"
                                        + "                   XX.AA.BB.CC.     \n " +
                                        "                 NO 25 ABC ABCDE    \n" +

                                        "                  +"+ timeStamp +"     \n" +
                                        "                   MMM 590019091      \n";
                                BILL = BILL
                                        + "-----------------------------------------------\n";


                                BILL = BILL + String.format("%1$-10s %2$10s %3$13s %4$10s", "Item", "Qty", "Rate", "Totel");
                                BILL = BILL + "\n";
                                BILL = BILL
                                        + "-----------------------------------------------";
                                BILL = BILL + "\n " + String.format("%1$-10s %2$10s %3$11s %4$10s", "item-001", "5", "10", "50.00");
                                BILL = BILL + "\n " + String.format("%1$-10s %2$10s %3$11s %4$10s", "item-002", "10", "5", "50.00");
                                BILL = BILL + "\n " + String.format("%1$-10s %2$10s %3$11s %4$10s", "item-003", "20", "10", "200.00");
                                BILL = BILL + "\n " + String.format("%1$-10s %2$10s %3$11s %4$10s", "item-004", "50", "10", "500.00");
                                BILL = BILL + "\n " + String.format("%1$-10s %2$10s %3$11s %4$10s", "item-001", "5", "10", "50.00");
                                BILL = BILL + "\n " + String.format("%1$-10s %2$10s %3$11s %4$10s", "item-002", "10", "5", "50.00");
                                BILL = BILL + "\n " + String.format("%1$-10s %2$10s %3$11s %4$10s", "item-003", "20", "10", "200.00");
                                BILL = BILL + "\n " + String.format("%1$-10s %2$10s %3$11s %4$10s", "item-004", "50", "10", "500.00");

                                BILL = BILL
                                        + "\n-----------------------------------------------";
                                BILL = BILL + "\n\n ";

                                BILL = BILL + "                   Total Qty:" + "      " + "85" + "\n";
                                BILL = BILL + "                   Total Value:" + "     " + "700.00" + "\n";

                                BILL = BILL
                                        + "-----------------------------------------------\n";
                                BILL = BILL + "\n\n ";
                                os.write(BILL.getBytes());
                                //This is printer specific code you can comment ==== > Start

                                // Setting height
                                int gs = 29;
                                os.write(intToByteArray(gs));
                                int h = 104;
                                os.write(intToByteArray(h));
                                int n = 162;
                                os.write(intToByteArray(n));

                                // Setting Width
                                int gs_width = 29;
                                os.write(intToByteArray(gs_width));
                                int w = 119;
                                os.write(intToByteArray(w));
                                int n_width = 2;
                                os.write(intToByteArray(n_width));


                            } catch (Exception e) {
                                Log.e("MainActivity", "Exe ", e);
                            }
                        }
                    };
                    t.start();
            if (mBluetoothAdapter != null) {
                mBluetoothAdapter.disable();
            }
        }
    };

    public static byte intToByteArray(int value) {
        byte[] b = ByteBuffer.allocate(4).putInt(value).array();

        for (int k = 0; k < b.length; k++) {
            System.out.println("Selva  [" + k + "] = " + "0x"
                    + UnicodeFormatter.byteToHex(b[k]));
        }

        return b[3];
    }

    public byte[] sel(int val) {
        ByteBuffer buffer = ByteBuffer.allocate(2);
        buffer.putInt(val);
        buffer.flip();
        return buffer.array();
    }


    public class WebAppInterface {
        Context mContext;
        WebAppInterface(Context c) {
            System.out.println("Context ........................");
            mContext = c;
        }

//        @SuppressLint("JavascriptInterface")
//        public void open(View view) { //
//            System.out.println("Click Pending .................");
//            String url = field.getText().toString();
//            myWebView.getSettings().setLoadsImagesAutomatically(true);
////            myWebView.getSettings().setJavaScriptEnabled(true);
//            myWebView.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
//            myWebView.loadUrl(url);
//            myWebView.addJavascriptInterface(new Object() {
                @JavascriptInterface
                public void performClick() {
                    System.out.println("clicked .............................");

                    mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
                    if (mBluetoothAdapter == null) {
                        Toast.makeText(MainActivity.this, "Message1", Toast.LENGTH_SHORT).show();
                    } else {
                        System.out.println("Not Null  .................");
                        if (!mBluetoothAdapter.isEnabled()) {
                            Intent enableBtIntent = new Intent(
                                    BluetoothAdapter.ACTION_REQUEST_ENABLE);
                            startActivityForResult(enableBtIntent,
                                    REQUEST_ENABLE_BT);
                        } else {
                            ListPairedDevices();
                            Intent connectIntent = new Intent(MainActivity.this,
                                    DeviceListActivity.class);
                            startActivityForResult(connectIntent,
                                    REQUEST_CONNECT_DEVICE);
                            if(connectIntent!=null){
                                System.out.println("connectIntent not Null/////");
                            }else{
                                System.out.println("connectIntent is Null///////");
                            }
                        }
                    }

                    Log.d("LOGIN::", "Clicked");
                    Toast.makeText(MainActivity.this, "Login clicked", Toast.LENGTH_LONG).show();


//                    Thread t = new Thread() {
//                        public void run() {
//                            try {
//                                OutputStream os = mBluetoothSocket
//                                        .getOutputStream();
//                                String BILL = "";
//
//                                BILL = "                   XXXX MART    \n"
//                                        + "                   XX.AA.BB.CC.     \n " +
//                                        "                 NO 25 ABC ABCDE    \n" +
//                                        "                  XXXXX YYYYYY      \n" +
//                                        "                   MMM 590019091      \n";
//                                BILL = BILL
//                                        + "-----------------------------------------------\n";
//
//
//                                BILL = BILL + String.format("%1$-10s %2$10s %3$13s %4$10s", "Item", "Qty", "Rate", "Totel");
//                                BILL = BILL + "\n";
//                                BILL = BILL
//                                        + "-----------------------------------------------";
//                                BILL = BILL + "\n " + String.format("%1$-10s %2$10s %3$11s %4$10s", "item-001", "5", "10", "50.00");
//                                BILL = BILL + "\n " + String.format("%1$-10s %2$10s %3$11s %4$10s", "item-002", "10", "5", "50.00");
//                                BILL = BILL + "\n " + String.format("%1$-10s %2$10s %3$11s %4$10s", "item-003", "20", "10", "200.00");
//                                BILL = BILL + "\n " + String.format("%1$-10s %2$10s %3$11s %4$10s", "item-004", "50", "10", "500.00");
//
//                                BILL = BILL
//                                        + "\n-----------------------------------------------";
//                                BILL = BILL + "\n\n ";
//
//                                BILL = BILL + "                   Total Qty:" + "      " + "85" + "\n";
//                                BILL = BILL + "                   Total Value:" + "     " + "700.00" + "\n";
//
//                                BILL = BILL
//                                        + "-----------------------------------------------\n";
//                                BILL = BILL + "\n\n ";
//                                os.write(BILL.getBytes());
//                                //This is printer specific code you can comment ==== > Start
//
//                                // Setting height
//                                int gs = 29;
//                                os.write(intToByteArray(gs));
//                                int h = 104;
//                                os.write(intToByteArray(h));
//                                int n = 162;
//                                os.write(intToByteArray(n));
//
//                                // Setting Width
//                                int gs_width = 29;
//                                os.write(intToByteArray(gs_width));
//                                int w = 119;
//                                os.write(intToByteArray(w));
//                                int n_width = 2;
//                                os.write(intToByteArray(n_width));
//
//
//                            } catch (Exception e) {
//                                Log.e("MainActivity", "Exe ", e);
//                            }
//                        }
//                    };
//                    t.start();
                }

    }

    private class MyBrowser extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            System.out.println("url method ............");
            view.loadUrl(url);
            return true;
        }
    }

    private void ListPairedDevices() {
        Set<BluetoothDevice> mPairedDevices = mBluetoothAdapter
                .getBondedDevices();
        if (mPairedDevices.size() > 0) {
            for (BluetoothDevice mDevice : mPairedDevices) {
                Log.v(TAG, "PairedDevices: " + mDevice.getName() + "  "
                        + mDevice.getAddress());
            }
            System.out.println("ListPairedDevices  .................");
        }
    }
    @Override
    public void onActivityResult(int mRequestCode, int mResultCode,
                                 Intent mDataIntent) {
        super.onActivityResult(mRequestCode, mResultCode, mDataIntent);

        switch (mRequestCode) {
            case REQUEST_CONNECT_DEVICE:
                if (mResultCode == Activity.RESULT_OK) {
                    Bundle mExtra = mDataIntent.getExtras();
                    String mDeviceAddress = mExtra.getString("DeviceAddress");
                    Log.v(TAG, "Coming incoming address " + mDeviceAddress);
                    mBluetoothDevice = mBluetoothAdapter
                            .getRemoteDevice(mDeviceAddress);
                    mBluetoothConnectProgressDialog = ProgressDialog.show(this,
                            "Connecting...", mBluetoothDevice.getName() + " : "
                                    + mBluetoothDevice.getAddress(), true, false);
                    Thread mBlutoothConnectThread = new Thread(this);
                    mBlutoothConnectThread.start();
                    // pairToDevice(mBluetoothDevice); This method is replaced by
                    // progress dialog with thread
                }
                break;

            case REQUEST_ENABLE_BT:
                if (mResultCode == Activity.RESULT_OK) {
                    ListPairedDevices();
                    Intent connectIntent = new Intent(MainActivity.this,
                            DeviceListActivity.class);
                    startActivityForResult(connectIntent, REQUEST_CONNECT_DEVICE);
                } else {
                    Toast.makeText(MainActivity.this, "Message", Toast.LENGTH_SHORT).show();
                }
                break;
        }
    }
}
//localStorage.setItem("id", _id);
//        Android.performClick();